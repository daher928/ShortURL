import json

import pytest
from short_url_service import service


class EncodePostRequest:
    def __init__(self, url):
        mimetype = 'application/json'
        headers = {
            'Content-Type': mimetype,
            'Accept': mimetype
        }
        self.headers = headers

        data = {
            "url": url
        }
        self.json_body = json.dumps(data)


@pytest.fixture
def client():
    service.config["TESTING"] = True
    with service.test_client() as client:
        yield client


def test_encode(client):
    post_request = EncodePostRequest('www.facebook.com')
    response = client.post("/encode", headers=post_request.headers, data=post_request.json_body)
    assert response.json['short_url'] == 'http://shrt.url/0'


def test_decode(client):
    response = client.get('/decode?short_url=http://shrt.url/0')
    assert response.json['original_url'] == 'www.facebook.com'


def test_mixed(client):
    url_to_short_map = dict()
    print("\nGenerate 10 shortURLs")
    for i in range(10):
        url = 'https://hexa3d.io/{}'.format("iteration_num_{}".format(i))
        hex3d_post_request = EncodePostRequest(url)
        resp = client.post("/encode", headers=hex3d_post_request.headers, data=hex3d_post_request.json_body)
        url_to_short_map[url] = resp.json['short_url']
        print("URL: {} --> Generated shortURL: {}".format(url, resp.json['short_url']))

    print("Decode 10 shortURLs")
    for url, short_url in url_to_short_map.items():
        decoded_url = client.get('/decode?short_url={}'.format(short_url)).json['original_url']
        assert decoded_url == url
        print("ShortURL: {} --> OriginalURL: {}".format(short_url, decoded_url))
